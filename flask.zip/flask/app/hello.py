
# 3] Palindrom Number  
from flask import Flask, render_template, request
app = Flask(__name__) 

@app.route('/check')
def check():
   return render_template('armstrong.html')

@app.route('/num',methods=['POST','GET'])
def num():
   if request.method == 'POST':
      num = request.form['arm']
      sum = 0
      chk = int(num)
      temp = int(num)
      while temp > 0:
         digit = temp % 10
         sum += digit ** 3
         temp //= 10

      if chk == sum:
         msg = f"This Number is {num} Armstrong Number"
         return render_template('armstrong.html',message=msg)
      else:
         msg = f"This Number is {num} Not Armstrong Number"
         return render_template('armstrong.html',message=msg)
 
'''from flask import Flask, render_template, request
app = Flask(__name__) 
@app.route('/<int:number>') 
def newnum(number): 
   num=number  
   sum1=0    
   temp=num
   while temp > 0: 
      new = temp % 10
      sum1 += new ** 3 
      temp //= 10 
 
   if num == sum1: 
      return "Armstrong Number" 
   else: 
      return "Not Armstrong Number"

app.run(host="0.0.0.0", port=5000)'''


# 2]
# from flask import Flask, render_template, request 
# app = Flask(__name__) 
 
# @app.route("/admin") 
# def newq(): 
#    return render_template("admin.html") 
 
# @app.route("/student") 
# def newqw(): 
#    return render_template("student.html") 
 
# @app.route("/teacher") 
# def newqe(): 
#    return render_template("teacher.html") 
 
# if __name__ == '__main__':
#    app.run(debug=True)


 

#1]
# from flask import Flask, render_template, request 
# app = Flask(__name__) 
 
# @app.route("/<name>/<age>") 
# def new(name,age): 
#    return render_template("index.html", name=name, age=age)

 


#4]
# from flask import Flask, render_template, request 
# app = Flask(__name__,template_folder="templates") 
 
# @app.route('/')
# def personalinfo():
#    return render_template('personalinfo.html')

# @app.route('/main' , methods = ['POST','GET']) 
# def main(): 
#    if request.method == 'POST': 
#       result = request.form 
#    return render_template("main.html", result=result) 


# if __name__ == '__main__':
#    app.run(debug=True)